#include "PCH.hpp"
#include <Emulator.hpp>
#ifdef __SWITCH__
#include <unistd.h>
#include <switch.h>
#include <dirent.h>
#include <iostream>
#include <vector>
#include <string>
#include <sys/stat.h>
#include <time.h>

#endif 

const double TimePerFrame = 1.0 / 60.0;
const unsigned int CyclesPerFrame = 70224;

struct SDLWindowDeleter { void operator()(SDL_Window* window) { if (window != nullptr) SDL_DestroyWindow(window); } };
struct SDLRendererDeleter { void operator()(SDL_Renderer* renderer) { if (renderer != nullptr) SDL_DestroyRenderer(renderer); } };
struct SDLTextureDeleter { void operator()(SDL_Texture* texture) { if (texture != nullptr) SDL_DestroyTexture(texture); } };

int windowWidth = 1280;
int windowHeight = 720;

std::unique_ptr<SDL_Renderer, SDLRendererDeleter> spRenderer;
std::unique_ptr<SDL_Texture, SDLTextureDeleter> spTexture;
Emulator emulator;
PadState pad;

int currentTheme = 0; 

u64 mapA = HidNpadButton_A;
u64 mapB = HidNpadButton_B;
u64 mapStart = HidNpadButton_Plus;
u64 mapSelect = HidNpadButton_Minus;

SDL_Color getThemeColor(int type) {
    if (currentTheme == 0) return (type == 0) ? SDL_Color{100, 255, 100} : SDL_Color{255, 255, 255}; 
    if (currentTheme == 1) return (type == 0) ? SDL_Color{255, 0, 255} : SDL_Color{255, 192, 203}; 
    if (currentTheme == 2) return (type == 0) ? SDL_Color{255, 255, 255} : SDL_Color{150, 150, 150}; 
    return SDL_Color{255, 255, 255};
}

void drawText(TTF_Font* font, const std::string& text, int x, int y, SDL_Color color) {
    SDL_Surface* surf = TTF_RenderText_Blended(font, text.c_str(), color);
    SDL_Texture* tex = SDL_CreateTextureFromSurface(spRenderer.get(), surf);
    SDL_Rect rect = {x, y, surf->w, surf->h};
    SDL_RenderCopy(spRenderer.get(), tex, nullptr, &rect);
    SDL_FreeSurface(surf);
    SDL_DestroyTexture(tex);
}

void Render(SDL_Renderer* pRenderer, SDL_Texture* pTexture, Emulator& emulator)
{
    SDL_SetRenderDrawColor(pRenderer, 0x00, 0x00, 0x00, 0xFF);
    SDL_RenderClear(pRenderer);

    byte* pPixels;
    int pitch = 0;
    SDL_LockTexture(pTexture, nullptr, (void**)&pPixels, &pitch);

    byte* pData = emulator.GetCurrentFrame();
    if (pData != nullptr) {
        memcpy(pPixels, pData, 160 * 144 * 4);
    }

    SDL_UnlockTexture(pTexture);
    SDL_Rect dstrect;
    dstrect.w = 160*5;
    dstrect.h = 144*5;
    dstrect.x = (windowWidth - dstrect.w)/2;
    dstrect.y = 0;
    SDL_RenderCopy(pRenderer, pTexture, nullptr, &dstrect);
    SDL_RenderPresent(pRenderer);
}

void VSyncCallback() { Render(spRenderer.get(), spTexture.get(), emulator); }

void ProcessInput(Emulator& emulator, bool& returnToMenu, u64 kHeld)
{
    SDL_PumpEvents();
    const Uint8 *keys = SDL_GetKeyboardState(NULL);
    byte input = JOYPAD_NONE;
    byte buttons = JOYPAD_NONE;

    if(keys[SDL_SCANCODE_W]) input |= JOYPAD_INPUT_UP;
    if(keys[SDL_SCANCODE_A]) input |= JOYPAD_INPUT_LEFT;
    if(keys[SDL_SCANCODE_S]) input |= JOYPAD_INPUT_DOWN;
    if(keys[SDL_SCANCODE_D]) input |= JOYPAD_INPUT_RIGHT;
    if(keys[SDL_SCANCODE_K]) buttons |= JOYPAD_BUTTONS_A;
    if(keys[SDL_SCANCODE_L]) buttons |= JOYPAD_BUTTONS_B;
    if(keys[SDL_SCANCODE_N]) buttons |= JOYPAD_BUTTONS_START;
    if(keys[SDL_SCANCODE_M]) buttons |= JOYPAD_BUTTONS_SELECT;

    // ВЫХОД В МЕНЮ ПО L + R + PLUS
    if ((kHeld & HidNpadButton_L) && (kHeld & HidNpadButton_R) && (kHeld & HidNpadButton_Plus)) {
        returnToMenu = true;
    }

    if (kHeld & mapStart) buttons |= JOYPAD_BUTTONS_START;
    if (kHeld & mapSelect) buttons |= JOYPAD_BUTTONS_SELECT;
    if (kHeld & HidNpadButton_Left) input |= JOYPAD_INPUT_LEFT;
    if (kHeld & HidNpadButton_Up) input |= JOYPAD_INPUT_UP;
    if (kHeld & HidNpadButton_Right) input |= JOYPAD_INPUT_RIGHT;
    if (kHeld & HidNpadButton_Down) input |= JOYPAD_INPUT_DOWN;
    if (kHeld & mapA) buttons |= JOYPAD_BUTTONS_A;
    if (kHeld & mapB) buttons |= JOYPAD_BUTTONS_B;

    emulator.SetInput(input, buttons);
}

#ifdef __SWITCH__
std::vector<std::string> scanRoms() {
    std::vector<std::string> roms;
    DIR* dir = opendir("sdmc:/switch/KirbyGB/roms/");
    if (dir == NULL) {
        mkdir("sdmc:/switch/KirbyGB/roms", 0777);
        return roms;
    }
    struct dirent* ent;
    while ((ent = readdir(dir)) != NULL) {
        std::string name = ent->d_name;
        if (name.length() > 3 && (name.substr(name.length() - 3) == ".gb" || name.substr(name.length() - 4) == ".gbc")) {
            roms.push_back(name);
        }
    }
    closedir(dir);
    return roms;
}
#endif

int main(int argc, char** argv)
{
    romfsInit();
    socketInitializeDefault();
    nxlinkStdio();

    struct stat st = { 0 };
    if (stat("sdmc:/switch/KirbyGB/roms", &st) == -1) {
        mkdir("sdmc:/switch/KirbyGB/roms", 0777);
    }
    
    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    padInitializeDefault(&pad);

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) return false;
    if( TTF_Init() == -1 ) return false;

    std::unique_ptr<SDL_Window, SDLWindowDeleter> spWindow = std::unique_ptr<SDL_Window, SDLWindowDeleter>(
        SDL_CreateWindow("Kirby GB/GBC", 0, 0, windowWidth, windowHeight, 0));
    if (spWindow == nullptr) return false;

    spRenderer = std::unique_ptr<SDL_Renderer, SDLRendererDeleter>(
        SDL_CreateRenderer(spWindow.get(), 0, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC));
    if (spRenderer == nullptr) return false;

    bool quitApp = false;
    int appState = 0; 

    int settingsIndex = 0;
    int remapIndex = 0;

    bool splashDone = false;
    while (!splashDone && appletMainLoop()) {
        padUpdate(&pad);
        if (padGetButtonsDown(&pad)) splashDone = true;
        
        SDL_SetRenderDrawColor(spRenderer.get(), 0, 0, 0, 255);
        SDL_RenderClear(spRenderer.get());
        TTF_Font* fontBig = TTF_OpenFont("romfs:/lazy.ttf", 60);
        TTF_Font* fontSmall = TTF_OpenFont("romfs:/lazy.ttf", 30);
        
        drawText(fontBig, "Kirby GB / GBC", 250, 200, getThemeColor(0));
        drawText(fontSmall, "Custom Emulator by Yarik", 420, 300, getThemeColor(1));
        drawText(fontSmall, "Press Any Button to Start", 420, 500, getThemeColor(1));
        
        TTF_CloseFont(fontBig);
        TTF_CloseFont(fontSmall);
        SDL_RenderPresent(spRenderer.get());
    }

    while (!quitApp && appletMainLoop()) {
        std::vector<std::string> romList;
#ifdef __SWITCH__
        romList = scanRoms();
#endif

        int selectedIndex = 0;
        bool gameSelected = false;
        std::string romPath = "";

        while (appState == 1 && appletMainLoop()) {
            padUpdate(&pad);
            u64 kDown = padGetButtonsDown(&pad);

            if (kDown & HidNpadButton_Down) settingsIndex = (settingsIndex + 1) % 3;
            if (kDown & HidNpadButton_Up) settingsIndex = (settingsIndex - 1 + 3) % 3;

            if (kDown & HidNpadButton_A) {
                if (settingsIndex == 0) currentTheme = (currentTheme + 1) % 3;
                else if (settingsIndex == 1) { appState = 2; remapIndex = 0; }
                else if (settingsIndex == 2) appState = 0;
            }
            if (kDown & HidNpadButton_B) appState = 0;

            SDL_SetRenderDrawColor(spRenderer.get(), 0, 0, 0, 255);
            SDL_RenderClear(spRenderer.get());
            TTF_Font* font = TTF_OpenFont("romfs:/lazy.ttf", 30);

            drawText(font, "SETTINGS", 20, 20, getThemeColor(0));
            std::string themes[] = {"Theme: GameBoy Green", "Theme: Kirby Pink/Purple", "Theme: Black & White"};
            drawText(font, (settingsIndex == 0 ? "> " : "  ") + themes[currentTheme], 20, 100, settingsIndex == 0 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, (settingsIndex == 1 ? "> " : "  ") + std::string("Remap Buttons"), 20, 150, settingsIndex == 1 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, (settingsIndex == 2 ? "> " : "  ") + std::string("Back"), 20, 200, settingsIndex == 2 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, "A: Select   B: Back", 20, 650, getThemeColor(1));

            TTF_CloseFont(font);
            SDL_RenderPresent(spRenderer.get());
        }

        while (appState == 2 && appletMainLoop()) {
            padUpdate(&pad);
            u64 kDown = padGetButtonsDown(&pad);

            if (kDown & HidNpadButton_Down) remapIndex = (remapIndex + 1) % 5;
            if (kDown & HidNpadButton_Up) remapIndex = (remapIndex - 1 + 5) % 5;
            if (kDown & HidNpadButton_B) appState = 1;

            if (kDown & HidNpadButton_A) {
                u64 newBtn = 0;
                while(appletMainLoop()) {
                    padUpdate(&pad);
                    u64 kHeld = padGetButtons(&pad);
                    if (kHeld & HidNpadButton_Y) newBtn = HidNpadButton_Y;
                    else if (kHeld & HidNpadButton_X) newBtn = HidNpadButton_X;
                    else if (kHeld & HidNpadButton_A) newBtn = HidNpadButton_A;
                    else if (kHeld & HidNpadButton_B) newBtn = HidNpadButton_B;
                    else if (kHeld & HidNpadButton_Plus) newBtn = HidNpadButton_Plus;
                    else if (kHeld & HidNpadButton_Minus) newBtn = HidNpadButton_Minus;
                    
                    if (newBtn != 0 && newBtn != HidNpadButton_A) {
                        if (remapIndex == 0) mapA = newBtn;
                        if (remapIndex == 1) mapB = newBtn;
                        if (remapIndex == 2) mapStart = newBtn;
                        if (remapIndex == 3) mapSelect = newBtn;
                        break;
                    }
                }
            }

            SDL_SetRenderDrawColor(spRenderer.get(), 0, 0, 0, 255);
            SDL_RenderClear(spRenderer.get());
            TTF_Font* font = TTF_OpenFont("romfs:/lazy.ttf", 30);

            drawText(font, "REMAP BUTTONS", 20, 20, getThemeColor(0));
            drawText(font, (remapIndex == 0 ? "> " : "  ") + std::string("GB A button"), 20, 100, remapIndex == 0 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, (remapIndex == 1 ? "> " : "  ") + std::string("GB B button"), 20, 150, remapIndex == 1 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, (remapIndex == 2 ? "> " : "  ") + std::string("GB Start"), 20, 200, remapIndex == 2 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, (remapIndex == 3 ? "> " : "  ") + std::string("GB Select"), 20, 250, remapIndex == 3 ? getThemeColor(0) : getThemeColor(1));
            drawText(font, (remapIndex == 4 ? "> " : "  ") + std::string("Back"), 20, 300, remapIndex == 4 ? getThemeColor(0) : getThemeColor(1));
            
            if (remapIndex == 4 && (kDown & HidNpadButton_A)) appState = 1;
            drawText(font, "A: Remap   B: Back", 20, 650, getThemeColor(1));

            TTF_CloseFont(font);
            SDL_RenderPresent(spRenderer.get());
        }

        if (romList.empty()) {
            while (appletMainLoop()) {
                padUpdate(&pad);
                if (padGetButtonsDown(&pad) & HidNpadButton_Plus) { quitApp = true; break; }
                if (padGetButtonsDown(&pad) & HidNpadButton_X) { appState = 1; break; }

                SDL_SetRenderDrawColor(spRenderer.get(), 0, 0, 0, 255);
                SDL_RenderClear(spRenderer.get());
                TTF_Font* font = TTF_OpenFont("romfs:/lazy.ttf", 30);
                drawText(font, "No ROMs found in /switch/KirbyGB/roms/", 20, 300, getThemeColor(1));
                drawText(font, "Press X for Settings | PLUS to Exit", 20, 650, getThemeColor(1));
                TTF_CloseFont(font);
                SDL_RenderPresent(spRenderer.get());
            }
            if (quitApp) break;
            continue;
        }

        while (!gameSelected && appState == 0 && appletMainLoop()) {
            padUpdate(&pad);
            u64 kDown = padGetButtonsDown(&pad);

            if (kDown & HidNpadButton_Down) selectedIndex = (selectedIndex + 1) % romList.size();
            if (kDown & HidNpadButton_Up) selectedIndex = (selectedIndex - 1 + romList.size()) % romList.size();
            if (kDown & HidNpadButton_X) { appState = 1; break; }
            if (kDown & HidNpadButton_Plus) { quitApp = true; break; }
            
            if (kDown & HidNpadButton_A) {
                romPath = "sdmc:/switch/KirbyGB/roms/" + romList[selectedIndex];
                gameSelected = true;
                break;
            }

            SDL_SetRenderDrawColor(spRenderer.get(), 0, 0, 0, 255);
            SDL_RenderClear(spRenderer.get());
            TTF_Font* font = TTF_OpenFont("romfs:/lazy.ttf", 24);
            
            time_t rawtime;
            struct tm * timeinfo;
            time(&rawtime);
            timeinfo = localtime(&rawtime);
            char timeStr[10];
            strftime(timeStr, sizeof(timeStr), "%H:%M", timeinfo);

            drawText(font, "Kirby GB/GBC - Select Game", 10, 10, getThemeColor(1));
            drawText(font, timeStr, 1100, 10, getThemeColor(1)); 

            int start = (selectedIndex > 7) ? selectedIndex - 7 : 0;
            int end = (start + 15 > (int)romList.size()) ? (int)romList.size() : start + 15;

            for (int i = start; i < end; i++) {
                SDL_Color color = (i == selectedIndex) ? getThemeColor(0) : getThemeColor(1);
                drawText(font, romList[i], 20, 60 + (i - start) * 35, color);
            }

            drawText(font, "UP/DOWN: Select | A: Play | X: Settings | PLUS: Exit", 10, windowHeight - 40, getThemeColor(1));

            TTF_CloseFont(font);
            SDL_RenderPresent(spRenderer.get());
        }

        if (quitApp) break;
        if (!gameSelected) continue;

        std::string bootROM = "sdmc:/switch/KirbyGB/gbc_bios.bin"; 
        if (stat(bootROM.c_str(), &st) == -1) {
            bootROM = ""; 
        }

        spTexture = std::unique_ptr<SDL_Texture, SDLTextureDeleter>(
            SDL_CreateTexture(spRenderer.get(), SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_STREAMING, 160, 144));

        if (emulator.Initialize(bootROM.empty() ? nullptr : bootROM.c_str(), romPath.c_str())) {
            emulator.SetVSyncCallback(&VSyncCallback);
            bool returnToMenu = false;
            unsigned int cycles = 0;
            Uint64 frameStart = SDL_GetPerformanceCounter();
            SDL_Event event;

            while (!returnToMenu && appletMainLoop()) {
                while (SDL_PollEvent(&event) != 0) {
                    if (event.type == SDL_QUIT) returnToMenu = true;
                }
                
                padUpdate(&pad);
                u64 kHeld = padGetButtons(&pad);

                ProcessInput(emulator, returnToMenu, kHeld);
                if (returnToMenu) break;

                bool fastForward = (kHeld & HidNpadButton_ZR);
                int steps = fastForward ? 4 : 1; 
                
                for(int i=0; i<steps; i++) {
                    while (cycles < CyclesPerFrame) cycles += emulator.Step();
                    cycles -= CyclesPerFrame;
                }

                Uint64 frameEnd = SDL_GetPerformanceCounter();
                while (true) {
                    frameEnd = SDL_GetPerformanceCounter();
                    double elapsed = (double)(frameEnd - frameStart) / SDL_GetPerformanceFrequency();
                    if (elapsed >= TimePerFrame) break;
                    if (fastForward) break; 
                }
                frameStart = frameEnd;
            }
            emulator.SetVSyncCallback(nullptr);
            emulator.Stop();
        } else {
            bool errQuit = false;
            while(!errQuit && appletMainLoop()) {
                padUpdate(&pad);
                if (padGetButtonsDown(&pad) & HidNpadButton_A) break;
                SDL_SetRenderDrawColor(spRenderer.get(), 0, 0, 0, 255);
                SDL_RenderClear(spRenderer.get());
                TTF_Font* font = TTF_OpenFont("romfs:/lazy.ttf", 24);
                drawText(font, "ERROR: Game Failed to Load!", 20, 300, SDL_Color{255,0,0});
                drawText(font, "File might be corrupted or unsupported.", 20, 340, SDL_Color{255,255,255});
                drawText(font, "Press A to return to menu.", 20, 400, SDL_Color{255,255,255});
                TTF_CloseFont(font);
                SDL_RenderPresent(spRenderer.get());
            }
        }
    }

    spTexture.reset();
    spRenderer.reset();
    spWindow.reset();
    socketExit();
    romfsExit();
    SDL_Quit();

    return 0;
}